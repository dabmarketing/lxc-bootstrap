#!/usr/bin/env bash
# End-to-end tests for new-project and promote-to-briefs.
# Invokes the scripts directly via /opt/tools/bin/<name> so tests don't depend on `make install`.
# Tests build under /tmp-smoketest/ (not /opt/projects/) to avoid clobbering real projects;
# the scripts hardcode /opt/projects/ as their target, so we run them under a chrooted PROJECTS_ROOT
# override (see SCAFFOLD_PROJECTS_ROOT below).

set -uo pipefail

TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SMOKE_ROOT="${TOOLS_DIR}/tmp-smoketest"

# Override targets used by the scripts under test (read by bin/new-project and
# bin/promote-to-briefs when SCAFFOLD_PROJECTS_ROOT / SCAFFOLD_MIRROR_ROOT are set).
export SCAFFOLD_PROJECTS_ROOT="${SMOKE_ROOT}/projects"
export SCAFFOLD_MIRROR_ROOT="${SMOKE_ROOT}/mirrors"

NEW_PROJECT="${TOOLS_DIR}/bin/new-project"
PROMOTE="${TOOLS_DIR}/bin/promote-to-briefs"

TESTS_RUN=0
TESTS_FAILED=0
CURRENT_TEST=""

# ---- assertions ----

_pass() { TESTS_RUN=$((TESTS_RUN+1)); echo "  ok - $1"; }
_fail() {
  TESTS_RUN=$((TESTS_RUN+1)); TESTS_FAILED=$((TESTS_FAILED+1))
  echo "  not ok - $1"
  [ -n "${2:-}" ] && echo "    $2"
}

assert_eq() { # desc actual expected
  if [ "$2" = "$3" ]; then _pass "$1"; else _fail "$1" "expected: $3 / actual: $2"; fi
}
assert_file_exists()    { [ -e "$2" ]   && _pass "$1" || _fail "$1" "missing: $2"; }
assert_dir_exists()     { [ -d "$2" ]   && _pass "$1" || _fail "$1" "missing dir: $2"; }
assert_file_not_exists(){ [ ! -e "$2" ] && _pass "$1" || _fail "$1" "should not exist: $2"; }
assert_grep() { # desc pattern path
  if grep -q -- "$2" "$3" 2>/dev/null; then _pass "$1"
  else _fail "$1" "pattern not in $3: $2"; fi
}
assert_no_grep() { # desc pattern path
  if grep -q -- "$2" "$3" 2>/dev/null; then _fail "$1" "pattern unexpectedly in $3: $2"
  else _pass "$1"; fi
}

# ---- lifecycle ----

setup() {
  rm -rf "$SMOKE_ROOT"
  mkdir -p "$SCAFFOLD_PROJECTS_ROOT" "$SCAFFOLD_MIRROR_ROOT"
}
teardown() { rm -rf "$SMOKE_ROOT"; }

run_test() {
  CURRENT_TEST="$1"
  echo
  echo "# $CURRENT_TEST"
  setup
  "$1"
  teardown
}

# ---- tests (filled in by Task 3) ----

# ---- new-project tests ----

test_new_project_creates_scaffold() {
  "$NEW_PROJECT" foo >/dev/null
  assert_eq          "exit code 0"             "$?"             "0"
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  assert_dir_exists  "project dir created"     "$p"
  assert_file_exists "CLAUDE.md exists"        "$p/CLAUDE.md"
  assert_file_exists ".gitignore exists"       "$p/.gitignore"
  assert_dir_exists  ".git exists"             "$p/.git"
  assert_grep "CLAUDE.md has Docker block"     "## First-run setup" "$p/CLAUDE.md"
  assert_grep "CLAUDE.md has memory pointer"   "## Memory"          "$p/CLAUDE.md"
  assert_no_grep "DATE substituted (no literal {{DATE}})" "{{DATE}}" "$p/CLAUDE.md"
  assert_grep ".gitignore has Python entry"    "__pycache__"        "$p/.gitignore"

  local commits
  commits=$(git -C "$p" log --oneline | wc -l)
  assert_eq "exactly one initial commit" "$commits" "1"
}

test_new_project_rejects_bad_name() {
  "$NEW_PROJECT" Foo >/dev/null 2>&1; assert_eq "exit 2 on uppercase"           "$?" "2"
  "$NEW_PROJECT" 1foo >/dev/null 2>&1; assert_eq "exit 2 on leading digit"      "$?" "2"
  "$NEW_PROJECT" foo_bar >/dev/null 2>&1; assert_eq "exit 2 on underscore"      "$?" "2"
  "$NEW_PROJECT" >/dev/null 2>&1; assert_eq "exit 2 on missing arg"             "$?" "2"
}

test_new_project_refuses_existing_nonempty() {
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  mkdir -p "$p"
  echo "stuff" > "$p/marker"
  "$NEW_PROJECT" foo >/dev/null 2>&1
  assert_eq "exit 1 on existing non-empty" "$?" "1"
  assert_file_exists "user file untouched" "$p/marker"
}

test_new_project_accepts_existing_empty() {
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  mkdir -p "$p"
  "$NEW_PROJECT" foo >/dev/null
  assert_eq "exit 0 on existing empty" "$?" "0"
  assert_file_exists "scaffolded into empty dir" "$p/CLAUDE.md"
}

# ---- promote-to-briefs tests ----

test_promote_basic_after_new_project() {
  "$NEW_PROJECT" foo >/dev/null
  "$PROMOTE" foo >/dev/null
  assert_eq "exit 0" "$?" "0"
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  local m="$SCAFFOLD_MIRROR_ROOT/foo-build-docs"
  assert_file_exists "SESSION_STATE.md created"     "$p/SESSION_STATE.md"
  assert_file_exists "project_brief created"        "$p/docs/foo_project_brief.md"
  assert_file_exists "session_brief template"       "$p/docs/specs/_template_session_brief.md"
  assert_file_exists "spec template"                "$p/docs/specs/_template_spec.md"
  assert_dir_exists  "external mirror created"      "$m"
  assert_file_not_exists "mirror is plain (no .git)" "$m/.git"
  assert_grep "CLAUDE.md has heavy preamble"        "## Heavy mode" "$p/CLAUDE.md"
  assert_grep "CLAUDE.md still has memory pointer"  "## Memory"     "$p/CLAUDE.md"
  assert_no_grep "NAME substituted in brief"        "{{NAME}}" "$p/docs/foo_project_brief.md"
  assert_grep "brief filename has project name"     "foo" "$p/docs/foo_project_brief.md"

  # promote-to-briefs MUST NOT auto-commit
  local commits
  commits=$(git -C "$p" log --oneline | wc -l)
  assert_eq "still exactly one commit (no auto-commit)" "$commits" "1"
}

test_promote_idempotent_skip_existing() {
  "$NEW_PROJECT" foo >/dev/null
  "$PROMOTE" foo >/dev/null

  # Modify a heavy file and confirm second run leaves it alone
  echo "user-edit" >> "$SCAFFOLD_PROJECTS_ROOT/foo/SESSION_STATE.md"
  local out
  out=$("$PROMOTE" foo 2>&1)
  assert_eq "exit 0 on re-run" "$?" "0"
  if echo "$out" | grep -q "\[skip\] .*SESSION_STATE.md"; then
    _pass "logs [skip] for SESSION_STATE.md"
  else
    _fail "logs [skip] for SESSION_STATE.md" "output: $out"
  fi
  assert_grep "user edit preserved" "user-edit" "$SCAFFOLD_PROJECTS_ROOT/foo/SESSION_STATE.md"

  # CLAUDE.md sentinel detection — heavy preamble already present
  if echo "$out" | grep -q "\[skip\] CLAUDE.md already has heavy preamble"; then
    _pass "CLAUDE.md skip log on re-run"
  else
    _fail "CLAUDE.md skip log on re-run" "output: $out"
  fi
}

test_promote_missing_claude_md() {
  # Project pre-dates new-project: no CLAUDE.md
  local p="$SCAFFOLD_PROJECTS_ROOT/legacy"
  mkdir -p "$p" && (cd "$p" && git init -q -b main && git commit -q --allow-empty -m "init")
  "$PROMOTE" legacy >/dev/null
  assert_eq "exit 0 on legacy project" "$?" "0"
  assert_file_exists "CLAUDE.md created"   "$p/CLAUDE.md"
  assert_grep "has heavy preamble"         "## Heavy mode"  "$p/CLAUDE.md"
  assert_grep "has memory pointer"         "## Memory"      "$p/CLAUDE.md"
  assert_grep "has promoted-on provenance" "Promoted to heavy mode" "$p/CLAUDE.md"
  assert_no_grep "DATE substituted"        "{{DATE}}" "$p/CLAUDE.md"
}

test_promote_refuses_non_repo() {
  local p="$SCAFFOLD_PROJECTS_ROOT/raw"
  mkdir -p "$p"  # no git init
  "$PROMOTE" raw >/dev/null 2>&1
  assert_eq "exit 1 on non-git target" "$?" "1"
}

test_promote_refuses_missing_target() {
  "$PROMOTE" doesnotexist >/dev/null 2>&1
  assert_eq "exit 1 on missing target" "$?" "1"
}

# ---- main ----

main() {
  for t in $(declare -F | awk '{print $3}' | grep '^test_'); do
    run_test "$t"
  done

  echo
  if [ "$TESTS_FAILED" -gt 0 ]; then
    echo "FAILED: $TESTS_FAILED of $TESTS_RUN"
    exit 1
  fi
  echo "PASSED: $TESTS_RUN tests"
}

main "$@"
