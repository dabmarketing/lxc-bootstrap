---
description: Promote the current project to the heavy session-brief workflow
---

You are promoting the current project (derived from the cwd, expected to be
under `/opt/projects/<name>/`) to the heavy session-brief workflow.

## Step 1: Run the bash scaffold

Run `/opt/tools/bin/promote-to-briefs` (no arg — it derives `<name>` from cwd).
This is idempotent and skip-existing — safe to re-run.

If the bash script exits non-zero, stop and surface the error to the user
verbatim. Do not attempt to recover.

## Step 2: Confirm scaffolding

Read `SESSION_STATE.md`, `docs/<name>_project_brief.md`, `docs/specs/`, and the
top of `CLAUDE.md`. Confirm to the user that scaffolding succeeded by listing
the files created or modified (from the bash output's `[create]`/`[update]`
lines). Note anything that was skipped.

## Step 3: Walk the user through the project brief

`docs/<name>_project_brief.md` is currently a skeleton. Fill it in by asking
the user one question at a time, in this order:

1. **What we're building** — one paragraph. Probe for: what it does, who/what
   it's for, what success looks like. Ask follow-ups until you have a crisp
   one-paragraph answer.
2. **Core design principles** — 3–5 non-negotiables. Probe for things the user
   would refuse to compromise on (architectural, ethical, operational).
3. **Stack & infrastructure** — confirmed services with cost; deferred services
   with the trigger that would un-defer them.
4. **Build sessions** — what's the rough decomposition into sessions? (Don't
   try to write each session's brief now — just titles and one-line goals.)
5. **Open questions** — what's unresolved? What would the user want to revisit
   after a few sessions of real work?

After each answer, write the section into `docs/<name>_project_brief.md`
immediately and show the user the diff. Don't batch — confirm section by
section.

## Step 4: Hand off

Do NOT commit. Tell the user:

> Heavy mode scaffolded. Review the diff (`git status` / `git diff`) — especially
> the prepended `CLAUDE.md` block and the populated project brief. Commit when
> you're satisfied.

End there. Do not start writing the first session brief — that's a separate
session.
