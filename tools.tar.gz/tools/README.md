# `/opt/tools/` — LXC project bootstrap tooling

Two commands for spinning up new projects on this dev-sandbox LXC:

- **`new-project <name>`** — light scaffold under `/opt/projects/<name>/`.
  Creates `git init` + `.gitignore` + a `CLAUDE.md` whose first thing Claude
  sees is a self-deleting Docker scaffold prompt. Ten seconds from idea to
  ready-to-work.
- **`promote-to-briefs <name>`** — heavy upgrade once a project earns the
  session-brief workflow. Adds `SESSION_STATE.md`, brief/spec templates under
  `docs/specs/`, and an external `/opt/<name>-build-docs/` scratch dir.
  Mirrors the `aziz-trader` pattern.

Plus a `/promote-to-briefs` Claude slash command that runs the bash scaffold,
then walks you through filling in the project brief interactively.

## Install

```bash
cd /opt/tools && make install
```

Symlinks land in `/usr/local/bin/`; the slash command lands in
`~/.claude/commands/`.

## Test

```bash
make test
```

Runs `tests/test_e2e.sh` — bash-driven end-to-end tests of both commands.

## Design

See `docs/specs/2026-05-04-new-project-bootstrap-design.md` for the full design
(decisions, error matrices, template content). The implementation plan lives at
`docs/plans/2026-05-04-new-project-bootstrap.md`.
