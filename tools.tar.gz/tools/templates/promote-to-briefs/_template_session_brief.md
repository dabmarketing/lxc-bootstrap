# Session N — <Title>

**Goal:** _(one sentence)_
**Out of scope:** _(what we're NOT doing this session)_
**Acceptance:** _(how we know we're done)_

---

## Context

_(what state the project is in, why this session matters now — link to
SESSION_STATE.md and the project brief)_

## Plan

_(numbered steps; each step should be small enough to commit independently)_

## Risks & open questions

_(things that might force a pivot mid-session)_
