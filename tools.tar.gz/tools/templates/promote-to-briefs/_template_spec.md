# <Topic> — Spec

**Status:** Draft / Approved / Implemented
**Context:** _(why this spec exists — bug, feature, refactor)_

---

## Problem

_(what's broken or missing, in concrete terms with examples)_

## Proposed change

_(the fix or feature, in enough detail that someone else could implement it)_

## Files affected

_(paths + nature of change)_

## Tests

_(how we verify the change works and didn't break adjacent things)_

## Out of scope

_(what we deliberately are NOT addressing here)_
