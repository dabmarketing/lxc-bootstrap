# New-project bootstrap — implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the `/opt/tools/` repo containing `new-project` and `promote-to-briefs` bash commands plus a `/promote-to-briefs` Claude slash command, and install them on this LXC.

**Architecture:** Two POSIX bash scripts under `/opt/tools/bin/`, symlinked into `/usr/local/bin/` via a Makefile install target. Templates live in `/opt/tools/templates/`. Tests are bash-driven end-to-end (assert files exist, exit codes, sentinel strings) — no bats dependency. Scripts locate their templates via `readlink -f "$0"` so they work whether called by direct path or symlink.

**Tech Stack:** bash, GNU coreutils, sed, git, make. Markdown templates. No external dependencies beyond what's already on Debian.

**Spec:** `/opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md` is the canonical reference. Every locked decision (Q1–Q6 in §2 of the spec) feeds these tasks. When in doubt, the spec wins.

**Local-only:** This is single-LXC tooling. No GitHub remote, no CI, no PR review. The "review" step is the user reading the diff before each commit.

---

## File structure

After implementation, `/opt/tools/` looks like:

```
/opt/tools/
  Makefile                                 # install / uninstall (Task 8)
  README.md                                # one-paragraph what-this-is (Task 9)
  .gitignore                               # tools-repo's own ignores (Task 1)
  bin/
    new-project                            # bash, +x (Task 5)
    promote-to-briefs                      # bash, +x (Task 6)
  templates/
    new-project/
      CLAUDE.md.tmpl                       # Task 4
      gitignore.tmpl                       # Task 4
    promote-to-briefs/
      claude_md_heavy_preamble.md.tmpl     # Task 4
      claude_md_minimal_addendum.md.tmpl   # Task 4
      SESSION_STATE.md.tmpl                # Task 4
      project_brief.md.tmpl                # Task 4
      _template_session_brief.md           # Task 4
      _template_spec.md                    # Task 4
  commands/
    promote-to-briefs.md                   # Task 7
  tests/
    test_e2e.sh                            # Tasks 2, 3 (skeleton + assertions)
  docs/
    specs/
      2026-05-04-new-project-bootstrap-design.md   # already exists
    plans/
      2026-05-04-new-project-bootstrap.md          # this file
```

Each unit:

- **`bin/new-project`** — fresh-project scaffold. Reads `templates/new-project/`, writes to `/opt/projects/<name>/`. Spec §4.
- **`bin/promote-to-briefs`** — heavy-mode upgrade. Reads `templates/promote-to-briefs/`, writes/updates files in an existing project + creates `/opt/<name>-build-docs/`. Spec §5.
- **`commands/promote-to-briefs.md`** — Claude slash-command body. Calls the bash via Bash tool, then walks user through brief. Spec §6.
- **`templates/`** — pure data. No logic. Spec §7.
- **`Makefile`** — `install` (symlinks + slash command copy) and `uninstall`. Spec §8.
- **`tests/test_e2e.sh`** — single bash test runner with named test functions. Asserts behavior of both bash commands end-to-end. Spec §9.

---

## Conventions used in this plan

**TDD for the bash scripts.** Tests in `tests/test_e2e.sh` are written before the scripts they exercise (Tasks 2–3 build the test harness; Tasks 5–6 implement the scripts to make those tests pass).

**Templates are pure data — no TDD.** Task 4 just creates them. Their correctness is verified indirectly through the e2e tests in Task 5/6 (which check that substituted output matches expectations).

**Frequent commits.** One commit per task. The user reviews the diff before each commit (sub-skill `subagent-driven-development` enforces this; if running inline, pause for the user).

**Exit-code conventions** (from spec §4 / §5 error matrices):

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Refusal (target exists non-empty / not a git repo / target missing for promote) |
| 2 | Usage error (missing arg, invalid name) |
| 3 | Templates not installed |
| 4 | `git init` failed (new-project only) |
| 5 | `git commit` failed (new-project only) |

---

## Task 1: Initialize `/opt/tools/` git repo

The spec already lives at `/opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md`. This plan also lives there now. Task 1 turns `/opt/tools/` into a git repo and makes the first commit.

**Files:**
- Create: `/opt/tools/.gitignore`
- Use existing: `/opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md`
- Use existing: `/opt/tools/docs/plans/2026-05-04-new-project-bootstrap.md`

- [ ] **Step 1: Verify spec and plan exist before init**

```bash
ls /opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md
ls /opt/tools/docs/plans/2026-05-04-new-project-bootstrap.md
```

Expected: both paths print without error. If either is missing, stop — don't proceed.

- [ ] **Step 2: Create `.gitignore` for the tools repo**

Write `/opt/tools/.gitignore`:

```
# Smoke-test scratch (used by tests/test_e2e.sh during runs)
/tmp-smoketest/

# Editor / OS
*.swp
.DS_Store
```

- [ ] **Step 3: `git init` and first commit**

```bash
cd /opt/tools && git init -b main
git add .gitignore docs/
git commit -m "Initial: design spec + implementation plan"
```

Expected: commit succeeds. `git log --oneline` shows one commit.

- [ ] **Step 4: Verify**

```bash
git -C /opt/tools log --oneline
git -C /opt/tools status
```

Expected: one commit visible, working tree clean.

---

## Task 2: Test harness skeleton (helpers + first failing test)

Build the bash test framework. The skeleton must run cleanly (no syntax errors) but every behavior assertion fails because nothing is implemented yet.

**Files:**
- Create: `/opt/tools/tests/test_e2e.sh`

- [ ] **Step 1: Write the test harness**

Create `/opt/tools/tests/test_e2e.sh` (mark executable in next step). Full content:

```bash
#!/usr/bin/env bash
# End-to-end tests for new-project and promote-to-briefs.
# Invokes the scripts directly via /opt/tools/bin/<name> so tests don't depend on `make install`.
# Tests build under /tmp-smoketest/ (not /opt/projects/) to avoid clobbering real projects;
# the scripts hardcode /opt/projects/ as their target, so we run them under a chrooted PROJECTS_ROOT
# override (see SCAFFOLD_PROJECTS_ROOT below).

set -uo pipefail

TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SMOKE_ROOT="${TOOLS_DIR}/tmp-smoketest"

# Override targets used by the scripts under test (read by bin/new-project and
# bin/promote-to-briefs when SCAFFOLD_PROJECTS_ROOT / SCAFFOLD_MIRROR_ROOT are set).
export SCAFFOLD_PROJECTS_ROOT="${SMOKE_ROOT}/projects"
export SCAFFOLD_MIRROR_ROOT="${SMOKE_ROOT}/mirrors"

NEW_PROJECT="${TOOLS_DIR}/bin/new-project"
PROMOTE="${TOOLS_DIR}/bin/promote-to-briefs"

TESTS_RUN=0
TESTS_FAILED=0
CURRENT_TEST=""

# ---- assertions ----

_pass() { TESTS_RUN=$((TESTS_RUN+1)); echo "  ok - $1"; }
_fail() {
  TESTS_RUN=$((TESTS_RUN+1)); TESTS_FAILED=$((TESTS_FAILED+1))
  echo "  not ok - $1"
  [ -n "${2:-}" ] && echo "    $2"
}

assert_eq() { # desc actual expected
  if [ "$2" = "$3" ]; then _pass "$1"; else _fail "$1" "expected: $3 / actual: $2"; fi
}
assert_file_exists()    { [ -e "$2" ]   && _pass "$1" || _fail "$1" "missing: $2"; }
assert_dir_exists()     { [ -d "$2" ]   && _pass "$1" || _fail "$1" "missing dir: $2"; }
assert_file_not_exists(){ [ ! -e "$2" ] && _pass "$1" || _fail "$1" "should not exist: $2"; }
assert_grep() { # desc pattern path
  if grep -q -- "$2" "$3" 2>/dev/null; then _pass "$1"
  else _fail "$1" "pattern not in $3: $2"; fi
}
assert_no_grep() { # desc pattern path
  if grep -q -- "$2" "$3" 2>/dev/null; then _fail "$1" "pattern unexpectedly in $3: $2"
  else _pass "$1"; fi
}

# ---- lifecycle ----

setup() {
  rm -rf "$SMOKE_ROOT"
  mkdir -p "$SCAFFOLD_PROJECTS_ROOT" "$SCAFFOLD_MIRROR_ROOT"
}
teardown() { rm -rf "$SMOKE_ROOT"; }

run_test() {
  CURRENT_TEST="$1"
  echo
  echo "# $CURRENT_TEST"
  setup
  "$1"
  teardown
}

# ---- tests (filled in by Task 3) ----

test_placeholder() {
  _fail "placeholder — replace in Task 3" "this should fail until real tests are written"
}

# ---- main ----

main() {
  for t in $(declare -F | awk '{print $3}' | grep '^test_'); do
    run_test "$t"
  done

  echo
  if [ "$TESTS_FAILED" -gt 0 ]; then
    echo "FAILED: $TESTS_FAILED of $TESTS_RUN"
    exit 1
  fi
  echo "PASSED: $TESTS_RUN tests"
}

main "$@"
```

- [ ] **Step 2: Make executable and run the placeholder**

```bash
chmod +x /opt/tools/tests/test_e2e.sh
/opt/tools/tests/test_e2e.sh
```

Expected output ends with `FAILED: 1 of 1` and exit code 1. The single `not ok` line is the placeholder. This proves the harness runs.

- [ ] **Step 3: Verify exit code**

```bash
/opt/tools/tests/test_e2e.sh; echo "exit=$?"
```

Expected: `exit=1`.

- [ ] **Step 4: Commit**

```bash
git -C /opt/tools add tests/test_e2e.sh
git -C /opt/tools commit -m "Add e2e test harness skeleton (placeholder failing)"
```

---

## Task 3: Write all behavior tests (still failing — scripts don't exist yet)

Replace the placeholder with concrete behavior tests. These cover both scripts end-to-end. They will all fail because `bin/new-project` and `bin/promote-to-briefs` don't exist yet — that's the TDD signal we want before Task 5/6.

**Files:**
- Modify: `/opt/tools/tests/test_e2e.sh` (replace `test_placeholder` with the 9 real tests below)

- [ ] **Step 1: Replace `test_placeholder` with the real test functions**

In `/opt/tools/tests/test_e2e.sh`, delete the `test_placeholder` function and insert these in its place:

```bash
# ---- new-project tests ----

test_new_project_creates_scaffold() {
  "$NEW_PROJECT" foo >/dev/null
  assert_eq          "exit code 0"             "$?"             "0"
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  assert_dir_exists  "project dir created"     "$p"
  assert_file_exists "CLAUDE.md exists"        "$p/CLAUDE.md"
  assert_file_exists ".gitignore exists"       "$p/.gitignore"
  assert_dir_exists  ".git exists"             "$p/.git"
  assert_grep "CLAUDE.md has Docker block"     "## First-run setup" "$p/CLAUDE.md"
  assert_grep "CLAUDE.md has memory pointer"   "## Memory"          "$p/CLAUDE.md"
  assert_no_grep "DATE substituted (no literal {{DATE}})" "{{DATE}}" "$p/CLAUDE.md"
  assert_grep ".gitignore has Python entry"    "__pycache__"        "$p/.gitignore"

  local commits
  commits=$(git -C "$p" log --oneline | wc -l)
  assert_eq "exactly one initial commit" "$commits" "1"
}

test_new_project_rejects_bad_name() {
  "$NEW_PROJECT" Foo >/dev/null 2>&1; assert_eq "exit 2 on uppercase"           "$?" "2"
  "$NEW_PROJECT" 1foo >/dev/null 2>&1; assert_eq "exit 2 on leading digit"      "$?" "2"
  "$NEW_PROJECT" foo_bar >/dev/null 2>&1; assert_eq "exit 2 on underscore"      "$?" "2"
  "$NEW_PROJECT" >/dev/null 2>&1; assert_eq "exit 2 on missing arg"             "$?" "2"
}

test_new_project_refuses_existing_nonempty() {
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  mkdir -p "$p"
  echo "stuff" > "$p/marker"
  "$NEW_PROJECT" foo >/dev/null 2>&1
  assert_eq "exit 1 on existing non-empty" "$?" "1"
  assert_file_exists "user file untouched" "$p/marker"
}

test_new_project_accepts_existing_empty() {
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  mkdir -p "$p"
  "$NEW_PROJECT" foo >/dev/null
  assert_eq "exit 0 on existing empty" "$?" "0"
  assert_file_exists "scaffolded into empty dir" "$p/CLAUDE.md"
}

# ---- promote-to-briefs tests ----

test_promote_basic_after_new_project() {
  "$NEW_PROJECT" foo >/dev/null
  "$PROMOTE" foo >/dev/null
  assert_eq "exit 0" "$?" "0"
  local p="$SCAFFOLD_PROJECTS_ROOT/foo"
  local m="$SCAFFOLD_MIRROR_ROOT/foo-build-docs"
  assert_file_exists "SESSION_STATE.md created"     "$p/SESSION_STATE.md"
  assert_file_exists "project_brief created"        "$p/docs/foo_project_brief.md"
  assert_file_exists "session_brief template"       "$p/docs/specs/_template_session_brief.md"
  assert_file_exists "spec template"                "$p/docs/specs/_template_spec.md"
  assert_dir_exists  "external mirror created"      "$m"
  assert_file_not_exists "mirror is plain (no .git)" "$m/.git"
  assert_grep "CLAUDE.md has heavy preamble"        "## Heavy mode" "$p/CLAUDE.md"
  assert_grep "CLAUDE.md still has memory pointer"  "## Memory"     "$p/CLAUDE.md"
  assert_no_grep "NAME substituted in brief"        "{{NAME}}" "$p/docs/foo_project_brief.md"
  assert_grep "brief filename has project name"     "foo" "$p/docs/foo_project_brief.md"

  # promote-to-briefs MUST NOT auto-commit
  local commits
  commits=$(git -C "$p" log --oneline | wc -l)
  assert_eq "still exactly one commit (no auto-commit)" "$commits" "1"
}

test_promote_idempotent_skip_existing() {
  "$NEW_PROJECT" foo >/dev/null
  "$PROMOTE" foo >/dev/null

  # Modify a heavy file and confirm second run leaves it alone
  echo "user-edit" >> "$SCAFFOLD_PROJECTS_ROOT/foo/SESSION_STATE.md"
  local out
  out=$("$PROMOTE" foo 2>&1)
  assert_eq "exit 0 on re-run" "$?" "0"
  if echo "$out" | grep -q "\[skip\] .*SESSION_STATE.md"; then
    _pass "logs [skip] for SESSION_STATE.md"
  else
    _fail "logs [skip] for SESSION_STATE.md" "output: $out"
  fi
  assert_grep "user edit preserved" "user-edit" "$SCAFFOLD_PROJECTS_ROOT/foo/SESSION_STATE.md"

  # CLAUDE.md sentinel detection — heavy preamble already present
  if echo "$out" | grep -q "\[skip\] CLAUDE.md already has heavy preamble"; then
    _pass "CLAUDE.md skip log on re-run"
  else
    _fail "CLAUDE.md skip log on re-run" "output: $out"
  fi
}

test_promote_missing_claude_md() {
  # Project pre-dates new-project: no CLAUDE.md
  local p="$SCAFFOLD_PROJECTS_ROOT/legacy"
  mkdir -p "$p" && (cd "$p" && git init -q -b main && git commit -q --allow-empty -m "init")
  "$PROMOTE" legacy >/dev/null
  assert_eq "exit 0 on legacy project" "$?" "0"
  assert_file_exists "CLAUDE.md created"   "$p/CLAUDE.md"
  assert_grep "has heavy preamble"         "## Heavy mode"  "$p/CLAUDE.md"
  assert_grep "has memory pointer"         "## Memory"      "$p/CLAUDE.md"
  assert_grep "has promoted-on provenance" "Promoted to heavy mode" "$p/CLAUDE.md"
  assert_no_grep "DATE substituted"        "{{DATE}}" "$p/CLAUDE.md"
}

test_promote_refuses_non_repo() {
  local p="$SCAFFOLD_PROJECTS_ROOT/raw"
  mkdir -p "$p"  # no git init
  "$PROMOTE" raw >/dev/null 2>&1
  assert_eq "exit 1 on non-git target" "$?" "1"
}

test_promote_refuses_missing_target() {
  "$PROMOTE" doesnotexist >/dev/null 2>&1
  assert_eq "exit 1 on missing target" "$?" "1"
}
```

- [ ] **Step 2: Run the test suite — every test must fail**

```bash
/opt/tools/tests/test_e2e.sh; echo "exit=$?"
```

Expected: many `not ok` lines (script not found). Exit code 1. The exact failure text doesn't matter — what matters is that the suite *runs* (no syntax errors) and *every* behavior test produces failed assertions. If any test passes, the test is wrong (false-positive risk).

- [ ] **Step 3: Commit**

```bash
git -C /opt/tools add tests/test_e2e.sh
git -C /opt/tools commit -m "Add behavior tests for new-project + promote-to-briefs (failing)"
```

---

## Task 4: Create all templates

Pure file creation, no logic. Tests in Task 3 will start passing relevant assertions once Task 5/6 wire scripts up to read these.

**Files:**
- Create: `/opt/tools/templates/new-project/CLAUDE.md.tmpl`
- Create: `/opt/tools/templates/new-project/gitignore.tmpl`
- Create: `/opt/tools/templates/promote-to-briefs/claude_md_heavy_preamble.md.tmpl`
- Create: `/opt/tools/templates/promote-to-briefs/claude_md_minimal_addendum.md.tmpl`
- Create: `/opt/tools/templates/promote-to-briefs/SESSION_STATE.md.tmpl`
- Create: `/opt/tools/templates/promote-to-briefs/project_brief.md.tmpl`
- Create: `/opt/tools/templates/promote-to-briefs/_template_session_brief.md`
- Create: `/opt/tools/templates/promote-to-briefs/_template_spec.md`

- [ ] **Step 1: Create `templates/new-project/CLAUDE.md.tmpl`** — copy verbatim from spec §7.1.

```markdown
## First-run setup — Docker scaffold

> This block is read by Claude on first launch in this project. After scaffolding
> is complete (or the user declines), Claude must delete this entire `## First-run
> setup` section from CLAUDE.md and commit.

Before doing anything else in this project, ask the user:

1. Does this project want a Docker scaffold? (Y/n — default Y)
2. If yes:
   - What's the primary language/runtime? (python | node | go | other — free text)
   - Are there any backing services? (postgres | redis | sqlite | none | other)
   - What ports need to be exposed? (default: none)
   - Single service, or multi-service compose? (single | multi)

Then scaffold:
- `Dockerfile` (or `docker/Dockerfile.<service>` if multi-service)
- `docker-compose.yml` at the repo root
- `.dockerignore`
- Stub `.env.example` if any service needs config

Match patterns from `/opt/projects/aziz-trader/` (bind-mount `./:/app`, named
volumes for data/logs, `env_file: .env`, dedicated network) where they fit; don't
copy aziz-specific service definitions.

If the user declines (`n`), still delete this block — they don't want to be
re-prompted next session.

After scaffolding (or declining): remove this `## First-run setup` section,
including the `---` divider below, then `git add -A && git commit -m "Scaffold
Docker setup"` (or `"Decline Docker scaffold"` if declined).

---

## Memory

This LXC has a persistent memory store at `/root/.claude/projects/-opt/memory/`.
Read `MEMORY.md` there for user/project/feedback context that applies across all
projects in `/opt/projects/`. Update it when you learn something durable.

---

*Bootstrapped via `new-project` on {{DATE}}. To upgrade to the heavy
session-brief workflow, run `/promote-to-briefs` from inside a Claude session.*
```

- [ ] **Step 2: Create `templates/new-project/gitignore.tmpl`** — verbatim from spec §7.2.

```
# Python
__pycache__/
*.py[cod]
*.egg-info/
.pytest_cache/
.coverage
htmlcov/
.mypy_cache/
.ruff_cache/

# Virtual envs
.venv/
venv/

# Secrets
.env
*.env.local

# Databases
*.db
*.db-journal
*.sqlite3

# Logs
*.log
logs/

# IDE
.vscode/
.idea/
*.swp

# OS
.DS_Store
Thumbs.db

# Build
dist/
build/

# Node
node_modules/
```

- [ ] **Step 3: Create `templates/promote-to-briefs/claude_md_heavy_preamble.md.tmpl`** — verbatim from spec §7.3. Note the trailing blank line and `---` divider matter; preserve exactly.

```markdown
## Heavy mode — session-brief workflow

This project uses the session-brief workflow:

- **`SESSION_STATE.md`** at the repo root is the single source of truth for
  "where are we right now." Read it before any non-trivial work. Update it on
  every commit and at every state transition.
- **`docs/{{NAME}}_project_brief.md`** is the canonical project brief — what
  we're building and why. Stable; rarely edited.
- **`docs/specs/`** holds per-session build briefs (`session_N_*_brief.md`)
  and per-task specs (`*_spec.md`). New work starts as a brief or spec here
  before any code is written.
- **`/opt/{{NAME}}-build-docs/`** is an external scratch dir for drafting
  briefs/specs during long brainstorming sessions, outside the working tree.
  Finalize and copy into `docs/specs/` before implementing.

Before any non-trivial work: read `SESSION_STATE.md`, then the relevant
brief/spec under `docs/specs/`. If neither exists for the work you're about
to do, draft one first.

---

```

- [ ] **Step 4: Create `templates/promote-to-briefs/claude_md_minimal_addendum.md.tmpl`** — verbatim from spec §7.4.

```markdown
## Memory

This LXC has a persistent memory store at `/root/.claude/projects/-opt/memory/`.
Read `MEMORY.md` there for user/project/feedback context that applies across all
projects in `/opt/projects/`. Update it when you learn something durable.

---

*Promoted to heavy mode via `/promote-to-briefs` on {{DATE}}.*
```

- [ ] **Step 5: Create `templates/promote-to-briefs/SESSION_STATE.md.tmpl`** — verbatim from spec §7.5.

```markdown
# Session State

**Single source of truth for "where are we right now."**
Future Claude reading this should be able to resume work without reading the
full conversation history. Update on every commit and at every state transition.

---

## Current state

- **Active session:** _(not started — fill in when first session opens)_
- **Latest commit on origin/main:** _(populated automatically as work happens)_
- **Working tree:** clean.
- **Branch:** main.

## What's running in production

_(none yet)_

## Next action

_(populated by current session brief)_

## Open questions

_(decisions deferred to a later session)_
```

- [ ] **Step 6: Create `templates/promote-to-briefs/project_brief.md.tmpl`** — verbatim from spec §7.6.

```markdown
# `{{NAME}}` — Project Brief

**Status:** Draft — first version written via `/promote-to-briefs`.

---

## 1. What we're building

_(one paragraph: what this project is, what it does, who/what it's for)_

## 2. Core design principles

_(non-negotiables that inform every downstream choice — 3–5 bullets)_

## 3. Stack & infrastructure

_(confirmed services, deferred services, run cost)_

## 4. Build sessions

_(numbered list of build sessions, each linking to its brief in docs/specs/)_

## 5. Open questions

_(things unresolved at brief-write time)_
```

- [ ] **Step 7: Create `templates/promote-to-briefs/_template_session_brief.md`** — verbatim from spec §7.7.

```markdown
# Session N — <Title>

**Goal:** _(one sentence)_
**Out of scope:** _(what we're NOT doing this session)_
**Acceptance:** _(how we know we're done)_

---

## Context

_(what state the project is in, why this session matters now — link to
SESSION_STATE.md and the project brief)_

## Plan

_(numbered steps; each step should be small enough to commit independently)_

## Risks & open questions

_(things that might force a pivot mid-session)_
```

- [ ] **Step 8: Create `templates/promote-to-briefs/_template_spec.md`** — verbatim from spec §7.8.

```markdown
# <Topic> — Spec

**Status:** Draft / Approved / Implemented
**Context:** _(why this spec exists — bug, feature, refactor)_

---

## Problem

_(what's broken or missing, in concrete terms with examples)_

## Proposed change

_(the fix or feature, in enough detail that someone else could implement it)_

## Files affected

_(paths + nature of change)_

## Tests

_(how we verify the change works and didn't break adjacent things)_

## Out of scope

_(what we deliberately are NOT addressing here)_
```

- [ ] **Step 9: Verify and commit**

```bash
ls /opt/tools/templates/new-project/
ls /opt/tools/templates/promote-to-briefs/
```

Expected:
```
# new-project/
CLAUDE.md.tmpl   gitignore.tmpl

# promote-to-briefs/
SESSION_STATE.md.tmpl
_template_session_brief.md
_template_spec.md
claude_md_heavy_preamble.md.tmpl
claude_md_minimal_addendum.md.tmpl
project_brief.md.tmpl
```

```bash
git -C /opt/tools add templates/
git -C /opt/tools commit -m "Add scaffold + heavy-mode templates"
```

---

## Task 5: Implement `bin/new-project`

Implements spec §4. Should make all `test_new_project_*` tests pass and leave `test_promote_*` tests still failing.

**Files:**
- Create: `/opt/tools/bin/new-project`

- [ ] **Step 1: Run new-project tests — confirm all fail**

```bash
/opt/tools/tests/test_e2e.sh 2>&1 | grep -E '^(# test_new_project|  not ok|  ok)' | head -40
```

Expected: every `test_new_project_*` group's assertions show `not ok` (script not yet present).

- [ ] **Step 2: Write `bin/new-project`**

```bash
#!/usr/bin/env bash
# new-project <name> — scaffold a new project at /opt/projects/<name>/
# See /opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md §4.

set -euo pipefail

# Locate template dir relative to the (possibly symlinked) script.
SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
TOOLS_DIR="$(dirname "$SCRIPT_DIR")"
TEMPLATES="$TOOLS_DIR/templates/new-project"

# Test override: SCAFFOLD_PROJECTS_ROOT lets tests redirect /opt/projects/.
PROJECTS_ROOT="${SCAFFOLD_PROJECTS_ROOT:-/opt/projects}"

usage() { echo "usage: new-project <kebab-name>" >&2; exit 2; }

# --- arg validation ---
[ $# -ge 1 ] || usage
NAME="$1"
if ! [[ "$NAME" =~ ^[a-z][a-z0-9-]*$ ]]; then
  echo "error: <name> must match ^[a-z][a-z0-9-]*\$" >&2
  exit 2
fi

TARGET="$PROJECTS_ROOT/$NAME"

# --- target dir handling ---
if [ -e "$TARGET" ]; then
  if [ -d "$TARGET" ] && [ -z "$(ls -A "$TARGET")" ]; then
    : # empty dir, ok
  else
    echo "error: $TARGET exists and is not empty" >&2
    exit 1
  fi
else
  mkdir -p "$PROJECTS_ROOT"
  mkdir "$TARGET"
fi

# --- templates present? ---
if [ ! -d "$TEMPLATES" ]; then
  echo "error: templates not found at $TEMPLATES — is /opt/tools/ installed?" >&2
  exit 3
fi

# --- render templates ---
DATE="$(date +%Y-%m-%d)"
sed -e "s/{{NAME}}/$NAME/g" -e "s/{{DATE}}/$DATE/g" \
    "$TEMPLATES/CLAUDE.md.tmpl" > "$TARGET/CLAUDE.md"
cp "$TEMPLATES/gitignore.tmpl" "$TARGET/.gitignore"

# --- git init + initial commit ---
cd "$TARGET"
if ! git init -q -b main; then
  echo "error: git init failed" >&2
  exit 4
fi
git add .
if ! git commit -q -m "Initial scaffold via new-project"; then
  echo "error: git commit failed" >&2
  exit 5
fi

# --- summary ---
cat <<EOF
✓ Created $TARGET/
  - CLAUDE.md (with first-run Docker scaffold prompt)
  - .gitignore
  - git initialized + initial commit on main

Next: cd $TARGET && claude
EOF
```

- [ ] **Step 3: Make executable**

```bash
chmod +x /opt/tools/bin/new-project
```

- [ ] **Step 4: Run new-project tests — confirm pass**

```bash
/opt/tools/tests/test_e2e.sh 2>&1 | grep -E '^# test_new_project' -A 20
```

Expected: every assertion under each `test_new_project_*` block is `ok`. (Tests under `test_promote_*` will still fail — that's correct; Task 6 fixes those.)

- [ ] **Step 5: Commit**

```bash
git -C /opt/tools add bin/new-project
git -C /opt/tools commit -m "Implement bin/new-project (light scaffold)"
```

---

## Task 6: Implement `bin/promote-to-briefs`

Implements spec §5. Should make all remaining tests pass.

**Files:**
- Create: `/opt/tools/bin/promote-to-briefs`

- [ ] **Step 1: Run promote tests — confirm all fail**

```bash
/opt/tools/tests/test_e2e.sh 2>&1 | grep -E '^# test_promote' -A 20 | head -60
```

Expected: every assertion under each `test_promote_*` block is `not ok`.

- [ ] **Step 2: Write `bin/promote-to-briefs`**

```bash
#!/usr/bin/env bash
# promote-to-briefs [<name>] — upgrade an existing project to the heavy session-brief workflow.
# See /opt/tools/docs/specs/2026-05-04-new-project-bootstrap-design.md §5.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
TOOLS_DIR="$(dirname "$SCRIPT_DIR")"
TEMPLATES="$TOOLS_DIR/templates/promote-to-briefs"

PROJECTS_ROOT="${SCAFFOLD_PROJECTS_ROOT:-/opt/projects}"
MIRROR_ROOT="${SCAFFOLD_MIRROR_ROOT:-/opt}"

usage() {
  echo "usage: promote-to-briefs [<name>]  (run from $PROJECTS_ROOT/<name>/ or pass <name>)" >&2
  exit 2
}

# --- resolve name ---
if [ $# -ge 1 ]; then
  NAME="$1"
else
  CWD="$(pwd -P)"
  if [[ "$CWD" == "$PROJECTS_ROOT/"* ]]; then
    REL="${CWD#$PROJECTS_ROOT/}"
    NAME="${REL%%/*}"
  else
    usage
  fi
fi

if ! [[ "$NAME" =~ ^[a-z][a-z0-9-]*$ ]]; then
  echo "error: <name> must match ^[a-z][a-z0-9-]*\$" >&2
  exit 2
fi

TARGET="$PROJECTS_ROOT/$NAME"
MIRROR="$MIRROR_ROOT/$NAME-build-docs"

# --- target preconditions ---
if [ ! -d "$TARGET" ]; then
  echo "error: $TARGET does not exist — run new-project first" >&2
  exit 1
fi
if [ ! -d "$TARGET/.git" ]; then
  echo "error: $TARGET is not a git repo — promote-to-briefs requires git init first" >&2
  exit 1
fi
if [ ! -d "$TEMPLATES" ]; then
  echo "error: templates not found at $TEMPLATES" >&2
  exit 3
fi

DATE="$(date +%Y-%m-%d)"

# Render a .tmpl file with substitution into a destination path.
render() { # src dest
  sed -e "s/{{NAME}}/$NAME/g" -e "s/{{DATE}}/$DATE/g" "$1" > "$2"
}

# Create a file from a template if it doesn't already exist.
create_if_missing() { # src dest desc
  if [ -e "$2" ]; then
    echo "[skip] $2 exists"
  else
    if [[ "$1" == *.tmpl ]]; then
      render "$1" "$2"
    else
      cp "$1" "$2"
    fi
    echo "[create] $2"
  fi
}

# --- skip-existing scaffold ---
create_if_missing "$TEMPLATES/SESSION_STATE.md.tmpl" "$TARGET/SESSION_STATE.md"

mkdir -p "$TARGET/docs" && echo "[ok] $TARGET/docs"
create_if_missing "$TEMPLATES/project_brief.md.tmpl" "$TARGET/docs/${NAME}_project_brief.md"

mkdir -p "$TARGET/docs/specs" && echo "[ok] $TARGET/docs/specs"
create_if_missing "$TEMPLATES/_template_session_brief.md" "$TARGET/docs/specs/_template_session_brief.md"
create_if_missing "$TEMPLATES/_template_spec.md"          "$TARGET/docs/specs/_template_spec.md"

mkdir -p "$MIRROR" && echo "[ok] $MIRROR"

# --- CLAUDE.md handling ---
SENTINEL="## Heavy mode — session-brief workflow"
if [ ! -e "$TARGET/CLAUDE.md" ]; then
  # Project pre-dates new-project: synthesize from preamble + addendum.
  {
    render "$TEMPLATES/claude_md_heavy_preamble.md.tmpl" /dev/stdout
    render "$TEMPLATES/claude_md_minimal_addendum.md.tmpl" /dev/stdout
  } > "$TARGET/CLAUDE.md"
  echo "[create] $TARGET/CLAUDE.md (was missing)"
elif grep -q -F "$SENTINEL" "$TARGET/CLAUDE.md"; then
  echo "[skip] CLAUDE.md already has heavy preamble"
else
  TMP="$(mktemp)"
  {
    render "$TEMPLATES/claude_md_heavy_preamble.md.tmpl" /dev/stdout
    cat "$TARGET/CLAUDE.md"
  } > "$TMP"
  mv "$TMP" "$TARGET/CLAUDE.md"
  echo "[update] $TARGET/CLAUDE.md (heavy preamble prepended)"
fi

# --- summary (no commit per Q6b) ---
cat <<EOF

✓ Promoted $TARGET/ to heavy mode.

Next: review the diff (git status / git diff), then commit when satisfied.
For an interactive walk-through filling in docs/${NAME}_project_brief.md,
run /promote-to-briefs from inside a Claude session in this directory.
EOF
```

- [ ] **Step 3: Make executable**

```bash
chmod +x /opt/tools/bin/promote-to-briefs
```

- [ ] **Step 4: Run full test suite — all should pass**

```bash
/opt/tools/tests/test_e2e.sh
```

Expected: ends with `PASSED: N tests` and exit 0. If any fail, fix the script (or test) before continuing — don't proceed to Task 7 with red tests.

- [ ] **Step 5: Commit**

```bash
git -C /opt/tools add bin/promote-to-briefs
git -C /opt/tools commit -m "Implement bin/promote-to-briefs (heavy-mode upgrade)"
```

---

## Task 7: Create the `/promote-to-briefs` Claude slash command

No tests — slash-command behavior is interactive and must be verified by the user manually (per spec §9 final paragraph).

**Files:**
- Create: `/opt/tools/commands/promote-to-briefs.md`

- [ ] **Step 1: Create the slash command file**

Write `/opt/tools/commands/promote-to-briefs.md` with content verbatim from spec §6:

```markdown
---
description: Promote the current project to the heavy session-brief workflow
---

You are promoting the current project (derived from the cwd, expected to be
under `/opt/projects/<name>/`) to the heavy session-brief workflow.

## Step 1: Run the bash scaffold

Run `/opt/tools/bin/promote-to-briefs` (no arg — it derives `<name>` from cwd).
This is idempotent and skip-existing — safe to re-run.

If the bash script exits non-zero, stop and surface the error to the user
verbatim. Do not attempt to recover.

## Step 2: Confirm scaffolding

Read `SESSION_STATE.md`, `docs/<name>_project_brief.md`, `docs/specs/`, and the
top of `CLAUDE.md`. Confirm to the user that scaffolding succeeded by listing
the files created or modified (from the bash output's `[create]`/`[update]`
lines). Note anything that was skipped.

## Step 3: Walk the user through the project brief

`docs/<name>_project_brief.md` is currently a skeleton. Fill it in by asking
the user one question at a time, in this order:

1. **What we're building** — one paragraph. Probe for: what it does, who/what
   it's for, what success looks like. Ask follow-ups until you have a crisp
   one-paragraph answer.
2. **Core design principles** — 3–5 non-negotiables. Probe for things the user
   would refuse to compromise on (architectural, ethical, operational).
3. **Stack & infrastructure** — confirmed services with cost; deferred services
   with the trigger that would un-defer them.
4. **Build sessions** — what's the rough decomposition into sessions? (Don't
   try to write each session's brief now — just titles and one-line goals.)
5. **Open questions** — what's unresolved? What would the user want to revisit
   after a few sessions of real work?

After each answer, write the section into `docs/<name>_project_brief.md`
immediately and show the user the diff. Don't batch — confirm section by
section.

## Step 4: Hand off

Do NOT commit. Tell the user:

> Heavy mode scaffolded. Review the diff (`git status` / `git diff`) — especially
> the prepended `CLAUDE.md` block and the populated project brief. Commit when
> you're satisfied.

End there. Do not start writing the first session brief — that's a separate
session.
```

- [ ] **Step 2: Commit**

```bash
git -C /opt/tools add commands/promote-to-briefs.md
git -C /opt/tools commit -m "Add /promote-to-briefs Claude slash command"
```

---

## Task 8: Create `Makefile`

**Files:**
- Create: `/opt/tools/Makefile`

- [ ] **Step 1: Write the Makefile**

```make
.PHONY: install uninstall test

install:
	ln -sf /opt/tools/bin/new-project       /usr/local/bin/new-project
	ln -sf /opt/tools/bin/promote-to-briefs /usr/local/bin/promote-to-briefs
	mkdir -p $${HOME}/.claude/commands
	cp -f /opt/tools/commands/promote-to-briefs.md $${HOME}/.claude/commands/promote-to-briefs.md
	@echo "✓ installed: new-project, promote-to-briefs, /promote-to-briefs slash command"

uninstall:
	rm -f /usr/local/bin/new-project
	rm -f /usr/local/bin/promote-to-briefs
	rm -f $${HOME}/.claude/commands/promote-to-briefs.md
	@echo "✓ uninstalled. /opt/tools/ itself is left in place — rm -rf manually if desired."

test:
	@/opt/tools/tests/test_e2e.sh
```

(Note: tabs, not spaces, before each command — Makefiles require tabs.)

- [ ] **Step 2: Commit**

```bash
git -C /opt/tools add Makefile
git -C /opt/tools commit -m "Add Makefile (install / uninstall / test)"
```

---

## Task 9: Create `README.md`

**Files:**
- Create: `/opt/tools/README.md`

- [ ] **Step 1: Write the README**

```markdown
# `/opt/tools/` — LXC project bootstrap tooling

Two commands for spinning up new projects on this dev-sandbox LXC:

- **`new-project <name>`** — light scaffold under `/opt/projects/<name>/`.
  Creates `git init` + `.gitignore` + a `CLAUDE.md` whose first thing Claude
  sees is a self-deleting Docker scaffold prompt. Ten seconds from idea to
  ready-to-work.
- **`promote-to-briefs <name>`** — heavy upgrade once a project earns the
  session-brief workflow. Adds `SESSION_STATE.md`, brief/spec templates under
  `docs/specs/`, and an external `/opt/<name>-build-docs/` scratch dir.
  Mirrors the `aziz-trader` pattern.

Plus a `/promote-to-briefs` Claude slash command that runs the bash scaffold,
then walks you through filling in the project brief interactively.

## Install

```bash
cd /opt/tools && make install
```

Symlinks land in `/usr/local/bin/`; the slash command lands in
`~/.claude/commands/`.

## Test

```bash
make test
```

Runs `tests/test_e2e.sh` — bash-driven end-to-end tests of both commands.

## Design

See `docs/specs/2026-05-04-new-project-bootstrap-design.md` for the full design
(decisions, error matrices, template content). The implementation plan lives at
`docs/plans/2026-05-04-new-project-bootstrap.md`.
```

- [ ] **Step 2: Commit**

```bash
git -C /opt/tools add README.md
git -C /opt/tools commit -m "Add README"
```

---

## Task 10: Run `make install` and verify integration

This is the spec §9 verification — confirms the install path works and `which` returns the right paths.

- [ ] **Step 1: Run `make install`**

```bash
cd /opt/tools && make install
```

Expected output:
```
ln -sf /opt/tools/bin/new-project       /usr/local/bin/new-project
ln -sf /opt/tools/bin/promote-to-briefs /usr/local/bin/promote-to-briefs
mkdir -p /root/.claude/commands
cp -f /opt/tools/commands/promote-to-briefs.md /root/.claude/commands/promote-to-briefs.md
✓ installed: new-project, promote-to-briefs, /promote-to-briefs slash command
```

- [ ] **Step 2: Verify symlinks**

```bash
which new-project
which promote-to-briefs
ls -la /usr/local/bin/new-project /usr/local/bin/promote-to-briefs
```

Expected: both `which` outputs are `/usr/local/bin/<name>`. The `ls -la` shows the symlinks pointing at `/opt/tools/bin/...`.

- [ ] **Step 3: Verify slash command**

```bash
test -s ~/.claude/commands/promote-to-briefs.md && echo "ok: slash command installed and non-empty"
```

Expected: `ok: slash command installed and non-empty`.

- [ ] **Step 4: Real-target smoke test (uses `/opt/projects/`, not the test override)**

```bash
new-project smoketest
promote-to-briefs smoketest
```

Expected: `new-project` prints success summary; `promote-to-briefs` prints `[create]`/`[ok]` lines and the success summary. Both exit 0.

- [ ] **Step 5: Verify the smoke artifacts**

```bash
ls -la /opt/projects/smoketest/
ls -la /opt/projects/smoketest/docs/
ls -la /opt/projects/smoketest/docs/specs/
ls -la /opt/smoketest-build-docs/
test -d /opt/smoketest-build-docs/.git && echo "FAIL: mirror is a git repo" || echo "ok: mirror is plain dir"
git -C /opt/projects/smoketest log --oneline
```

Expected:
- `smoketest/` contains `CLAUDE.md`, `.gitignore`, `SESSION_STATE.md`, `docs/`.
- `smoketest/docs/` contains `smoketest_project_brief.md` and `specs/`.
- `smoketest/docs/specs/` contains both `_template_*` files.
- `/opt/smoketest-build-docs/` exists and the printed line is `ok: mirror is plain dir`.
- `git log --oneline` shows exactly **one** commit (`Initial scaffold via new-project`) — promote-to-briefs did NOT auto-commit.

- [ ] **Step 6: Re-run promote-to-briefs and confirm idempotency**

```bash
promote-to-briefs smoketest 2>&1 | grep -E '^\[skip\]'
```

Expected: at least 4 `[skip]` lines (SESSION_STATE.md, project_brief.md, both `_template_*.md`, plus `[skip] CLAUDE.md already has heavy preamble`).

- [ ] **Step 7: Cleanup smoke artifacts**

```bash
rm -rf /opt/projects/smoketest /opt/smoketest-build-docs
ls /opt/projects/ | grep -v aziz-trader || echo "ok: only aziz-trader remains"
```

Expected: `ok: only aziz-trader remains`.

- [ ] **Step 8: Final commit (working tree should be clean — nothing to commit)**

```bash
git -C /opt/tools status
```

Expected: `nothing to commit, working tree clean`. If anything is dirty (e.g., a stray `tmp-smoketest/`), investigate before continuing — the `.gitignore` from Task 1 should already cover it.

```bash
git -C /opt/tools log --oneline
```

Expected: a clean linear history of one commit per task (Tasks 1–9), in order.

---

## Self-review

**Spec coverage check** (every spec section has a task implementing it):

- §1 Goal — covered by the whole plan.
- §2 Locked decisions — referenced in tasks where each decision lands (e.g., Q5b "initial commit" → Task 5 step 2; Q6b "no auto-commit" → Task 6 script + Task 6 step 4 test).
- §3 File layout — Task 1 (.gitignore), Task 4 (templates), Tasks 5/6 (bin), Task 7 (commands), Task 8 (Makefile), Task 9 (README).
- §4 `new-project` full spec — Task 5 (impl) + Task 3 (tests).
- §5 `promote-to-briefs` full spec — Task 6 (impl) + Task 3 (tests).
- §6 slash command — Task 7.
- §7 templates — Task 4 (all 8 sub-templates).
- §8 Makefile — Task 8.
- §9 verification — Task 10 (install + e2e + cleanup).
- §10 out of scope — explicitly not in the plan.
- §11 future work — explicitly not in the plan.

**Gaps found:** None.

**Placeholder scan:** No "TBD", "TODO", "implement later", "similar to" in the steps. Every step shows actual code or actual commands with expected output.

**Type/identifier consistency:**
- `SCAFFOLD_PROJECTS_ROOT` and `SCAFFOLD_MIRROR_ROOT` env-var names match across `tests/test_e2e.sh` (Task 2), `bin/new-project` (Task 5), and `bin/promote-to-briefs` (Task 6).
- Sentinel string `"## Heavy mode — session-brief workflow"` matches between the heavy preamble template (Task 4 step 3) and the grep in `bin/promote-to-briefs` (Task 6 step 2). The em dash (`—`) is the same character in both.
- Exit codes 1/2/3/4/5 used consistently with the table in the "Conventions" section above and with the spec error matrices (§4, §5).
- File names with `{{NAME}}` substitution (`docs/{{NAME}}_project_brief.md`) match the test assertions (`docs/foo_project_brief.md`).

---

## Execution Handoff

Plan complete and saved to `/opt/tools/docs/plans/2026-05-04-new-project-bootstrap.md`. Two execution options:

**1. Subagent-Driven (recommended)** — fresh subagent per task, two-stage review between tasks, fast iteration with the user reviewing each commit.

**2. Inline Execution** — execute tasks here in this session using `executing-plans`, with checkpoints after each task for the user to review.

Which approach?
