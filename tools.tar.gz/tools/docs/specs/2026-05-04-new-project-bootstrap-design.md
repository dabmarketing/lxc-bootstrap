# New-project bootstrap — design

**Status:** Approved (brainstorming, 2026-05-04). Awaiting implementation plan via `writing-plans`.
**Companion docs:** none yet — this is the canonical design.
**Repo target:** `/opt/tools/` on this dev-sandbox LXC.

---

## 1. Goal

A repeatable two-tier project bootstrap for `/opt/projects/<name>/` on this LXC:

- **`new-project <name>`** — light scaffold: directory, `git init`, `.gitignore`, a `CLAUDE.md` whose first thing Claude sees is a self-deleting Docker scaffold prompt. Ten seconds from idea to "ready to start working."
- **`promote-to-briefs <name>`** — heavy upgrade: adds `SESSION_STATE.md`, a project-brief template, `docs/specs/` with brief/spec templates, an external `/opt/<name>-build-docs/` scratch dir, and prepends a heavy-mode preamble to `CLAUDE.md`. Mirrors the aziz-trader pattern (`/opt/projects/aziz-trader/` + `/opt/aziz-build-docs/`).

The split exists because most projects don't earn the heavy session-brief workflow. Light is the default; heavy is opt-in once the project proves it deserves the ceremony.

## 2. Decisions locked during brainstorming

These were resolved in dialogue (Q1–Q6) and are the foundation for everything below.

| # | Decision | Why |
|---|---|---|
| Q1 | Bash scripts under `/opt/tools/bin/`, symlinked into `/usr/local/bin/`. Plus a `/promote-to-briefs` Claude slash command for the interactive heavy flow. | Keeps tooling self-contained under `/opt/`; symlinks avoid `~/.bashrc` PATH edits and work in cron/systemd. The slash command exists because heavy-mode promotion is best triggered from inside a running Claude session. `new-project` stays bash-only (you can't be inside a Claude session in a not-yet-existent dir). |
| Q2 | "Docker scaffold prompt" = a self-deleting `## First-run setup` block at the top of the generated `CLAUDE.md`. | A separate file adds friction; stub files leak half-baked config; interactive-at-create-time forces decisions before you've thought about the project. The block is visible, reversible, and triggers when Claude is already in problem-solving mode. |
| Q3 | Heavy delta = full aziz parity with a **plain-directory** external mirror (not a git repo). | The aziz pattern works because friction-free editing matters more than draft history when iterating on a brief. Git history of brief drafts is rarely useful. |
| Q4a | Light `CLAUDE.md` = Docker block + memory pointer + provenance line. No empty conventions stubs. | Memory pointer is a free win. Provenance line is what makes `/promote-to-briefs` discoverable months later. Empty stubs rot. |
| Q4b | Generic catchall `.gitignore` (Python + Node + OS + editor). No `--lang` flag at create time. | At create time you don't always know the stack; aziz-trader's existing `.gitignore` is itself the generic-catchall pattern. `--lang` is YAGNI. |
| Q5a | `new-project <name>` refuses if the dir exists and is non-empty. Empty existing dir is OK. | Refusing on existing-non-empty is the safe default. Allowing an empty pre-existing dir handles the common "I `mkdir`'d by reflex" case. No `--force` flag (footgun). |
| Q5b | `new-project` makes an initial git commit (`Initial scaffold via new-project`). | Clean starting point. `git commit --amend` is one command if you want to amend. |
| Q5c | Name validation: enforce `^[a-z][a-z0-9-]*$` (lowercase kebab). Refuse otherwise. | Matches aziz convention; flows safely into Docker container names, hostnames, the external scratch dir name, etc., without quoting. |
| Q6a | `promote-to-briefs` is **skip-existing** — creates only files that don't yet exist. No error on re-run. | Surgical recovery without ceremony. Refuse-on-promoted would force `rm` before retrying for no reason. |
| Q6b | `promote-to-briefs` does **not** auto-commit. | Promotion modifies a non-trivial existing file (`CLAUDE.md`) — the diff benefits from manual review before commit. (Contrast with `new-project`, where there's nothing to review.) |
| Q6c | Slash command does mechanical bash scaffolding **plus** an interactive walk-through filling in `docs/<name>_project_brief.md`. | Brief-drafting is the highest-value part of going heavy and the part most likely to be skipped if not prompted. The bash + slash-command split keeps mechanical and LLM work cleanly separable. |

## 3. File layout

```
/opt/tools/
  Makefile                                 # install / uninstall
  README.md                                # one-paragraph what-this-is
  bin/
    new-project                            # bash, +x
    promote-to-briefs                      # bash, +x
  templates/
    new-project/
      CLAUDE.md.tmpl                       # light template (with {{NAME}}, {{DATE}})
      gitignore.tmpl                       # generic catchall — copied to .gitignore
    promote-to-briefs/
      claude_md_heavy_preamble.md.tmpl     # prepended to existing CLAUDE.md
      claude_md_minimal_addendum.md.tmpl   # used only when CLAUDE.md is missing (fallback path)
      SESSION_STATE.md.tmpl
      project_brief.md.tmpl                # → docs/{{NAME}}_project_brief.md
      _template_session_brief.md           # copied as-is (no substitution needed)
      _template_spec.md                    # copied as-is
  commands/
    promote-to-briefs.md                   # Claude slash command
  docs/
    specs/
      2026-05-04-new-project-bootstrap-design.md   # this doc

# Symlinks (created by `make install`):
/usr/local/bin/new-project        → /opt/tools/bin/new-project
/usr/local/bin/promote-to-briefs  → /opt/tools/bin/promote-to-briefs

# Slash command (copied by `make install`, not symlinked — Claude reads from this path):
~/.claude/commands/promote-to-briefs.md
```

**Substitution convention:** `{{NAME}}` and `{{DATE}}` are replaced via `sed` at scaffold time. Files ending in `.tmpl` get substitution; files without `.tmpl` are copied as-is. Templates without substitution don't get the `.tmpl` suffix so they're identifiable at a glance.

## 4. `new-project <name>` — full spec

**Synopsis.**

```
new-project <name>
```

**Arguments.**

- `<name>` — required. Must match `^[a-z][a-z0-9-]*$`.

**Behavior.**

1. Validate `<name>` against the regex. On mismatch, exit 2 with usage.
2. Compute `target=/opt/projects/<name>`.
3. If `/opt/projects/` does not exist, `mkdir -p /opt/projects/`.
4. Check `target`:
   - If exists and not empty → exit 1: `error: /opt/projects/<name> exists and is not empty`.
   - If exists and empty → proceed.
   - If does not exist → `mkdir "$target"`.
5. Verify templates exist at `/opt/tools/templates/new-project/`. On missing, exit 3 with `error: templates not found at <path> — is /opt/tools/ installed?`.
6. Render templates into `target` with `{{NAME}}` ← `<name>`, `{{DATE}}` ← `$(date +%Y-%m-%d)`:
   - `CLAUDE.md.tmpl` → `CLAUDE.md`
   - `gitignore.tmpl` → `.gitignore`
7. `cd "$target" && git init -b main`. On failure: print error, leave dir in place (don't auto-cleanup), exit 4.
8. `git add . && git commit -m "Initial scaffold via new-project"`. On failure: print error, exit 5. Leave the staged files for the user to inspect.
9. Print success summary:

   ```
   ✓ Created /opt/projects/<name>/
     - CLAUDE.md (with first-run Docker scaffold prompt)
     - .gitignore
     - git initialized + initial commit on main

   Next: cd /opt/projects/<name> && claude
   ```

**Error matrix.**

| Case | Exit | Message |
|---|---|---|
| Missing `<name>` arg | 2 | `usage: new-project <kebab-name>` |
| `<name>` fails regex | 2 | `error: <name> must match ^[a-z][a-z0-9-]*$` |
| `target` non-empty | 1 | `error: /opt/projects/<name> exists and is not empty` |
| Templates missing | 3 | `error: templates not found at /opt/tools/templates/new-project/ — is /opt/tools/ installed?` |
| `git init` fails | 4 | bubble git's stderr |
| `git commit` fails | 5 | bubble git's stderr |

## 5. `promote-to-briefs [<name>]` — full spec

**Synopsis.**

```
promote-to-briefs [<name>]
```

**Arguments.**

- `<name>` — optional. If omitted, derived from cwd basename if cwd is under `/opt/projects/`. Otherwise required.

**Behavior.**

1. Resolve `<name>`:
   - If arg given, use it.
   - Else if `pwd -P` starts with `/opt/projects/` and has at least one path component after, use that component.
   - Else exit 2: `usage: promote-to-briefs [<name>]  (run from /opt/projects/<name>/ or pass <name>)`.
2. Validate `<name>` against the kebab regex. On mismatch, exit 2.
3. Compute `target=/opt/projects/<name>` and `mirror=/opt/<name>-build-docs`.
4. Verify `target` exists. On missing, exit 1: `error: /opt/projects/<name> does not exist — run new-project first`.
5. Verify `target/.git` exists. On missing, exit 1: `error: <target> is not a git repo — promote-to-briefs requires git init first`. (No auto-`git init` — promotion of a non-repo is almost certainly a mistake.)
6. Verify templates exist at `/opt/tools/templates/promote-to-briefs/`. On missing, exit 3.
7. Skip-existing scaffold. Log conventions for every line:
   - `[create] <path>` — file did not exist, was just written.
   - `[skip] <path> exists` — file already existed; left untouched.
   - `[ok] <path>` — directory now exists (whether we created it or it was already there). `mkdir -p` doesn't distinguish, so we don't either.

   Steps (in order):
   - `target/SESSION_STATE.md` — render from `SESSION_STATE.md.tmpl` (substitute `{{NAME}}`, `{{DATE}}`).
   - `target/docs/` — `mkdir -p`, log `[ok]`.
   - `target/docs/<name>_project_brief.md` — render from `project_brief.md.tmpl`.
   - `target/docs/specs/` — `mkdir -p`, log `[ok]`.
   - `target/docs/specs/_template_session_brief.md` — copy as-is.
   - `target/docs/specs/_template_spec.md` — copy as-is.
   - `mirror` — `mkdir -p`, log `[ok] <mirror>`.
8. `CLAUDE.md` handling:
   - If `target/CLAUDE.md` does **not** exist (project pre-dates `new-project`):
     - Concatenate `claude_md_heavy_preamble.md.tmpl` + `claude_md_minimal_addendum.md.tmpl`, run substitution (`{{NAME}}`, `{{DATE}}`), write to `target/CLAUDE.md`. Log `[create] CLAUDE.md (was missing)`. (See §7.4 for the addendum's content; it carries the memory pointer + a "promoted on" provenance line — the bits the missing CLAUDE.md would otherwise lack.)
   - Else if `CLAUDE.md` already contains the sentinel string `## Heavy mode — session-brief workflow`:
     - Log `[skip] CLAUDE.md already has heavy preamble`.
   - Else:
     - Render `claude_md_heavy_preamble.md.tmpl` and **prepend** to `target/CLAUDE.md` (preamble + blank line + existing content). Log `[update] CLAUDE.md (heavy preamble prepended)`.
9. Print summary:

   ```
   ✓ Promoted /opt/projects/<name>/ to heavy mode.

   Files created/updated:
     <list of [create]/[update] lines>

   Skipped (already existed):
     <list of [skip] lines>

   Next: review the diff (git status / git diff), then commit when satisfied.
   For an interactive walk-through filling in docs/<name>_project_brief.md,
   run /promote-to-briefs from inside a Claude session in this directory.
   ```

10. **Do not commit.** Exit 0.

**Error matrix.**

| Case | Exit | Message |
|---|---|---|
| `<name>` not derivable + not given | 2 | usage line |
| `<name>` fails regex | 2 | `error: <name> must match ^[a-z][a-z0-9-]*$` |
| Target dir missing | 1 | `error: /opt/projects/<name> does not exist — run new-project first` |
| Target not a git repo | 1 | `error: <target> is not a git repo — promote-to-briefs requires git init first` |
| Templates missing | 3 | `error: templates not found at /opt/tools/templates/promote-to-briefs/` |

## 6. `/promote-to-briefs` slash command

Lives at `~/.claude/commands/promote-to-briefs.md`. When invoked from inside a Claude session, Claude follows this body as a prompt:

```markdown
---
description: Promote the current project to the heavy session-brief workflow
---

You are promoting the current project (derived from the cwd, expected to be
under `/opt/projects/<name>/`) to the heavy session-brief workflow.

## Step 1: Run the bash scaffold

Run `/opt/tools/bin/promote-to-briefs` (no arg — it derives `<name>` from cwd).
This is idempotent and skip-existing — safe to re-run.

If the bash script exits non-zero, stop and surface the error to the user
verbatim. Do not attempt to recover.

## Step 2: Confirm scaffolding

Read `SESSION_STATE.md`, `docs/<name>_project_brief.md`, `docs/specs/`, and the
top of `CLAUDE.md`. Confirm to the user that scaffolding succeeded by listing
the files created or modified (from the bash output's `[create]`/`[update]`
lines). Note anything that was skipped.

## Step 3: Walk the user through the project brief

`docs/<name>_project_brief.md` is currently a skeleton. Fill it in by asking
the user one question at a time, in this order:

1. **What we're building** — one paragraph. Probe for: what it does, who/what
   it's for, what success looks like. Ask follow-ups until you have a crisp
   one-paragraph answer.
2. **Core design principles** — 3–5 non-negotiables. Probe for things the user
   would refuse to compromise on (architectural, ethical, operational).
3. **Stack & infrastructure** — confirmed services with cost; deferred services
   with the trigger that would un-defer them.
4. **Build sessions** — what's the rough decomposition into sessions? (Don't
   try to write each session's brief now — just titles and one-line goals.)
5. **Open questions** — what's unresolved? What would the user want to revisit
   after a few sessions of real work?

After each answer, write the section into `docs/<name>_project_brief.md`
immediately and show the user the diff. Don't batch — confirm section by
section.

## Step 4: Hand off

Do NOT commit. Tell the user:

> Heavy mode scaffolded. Review the diff (`git status` / `git diff`) — especially
> the prepended `CLAUDE.md` block and the populated project brief. Commit when
> you're satisfied.

End there. Do not start writing the first session brief — that's a separate
session.
```

## 7. Template content

All templates are reproduced here in full so the implementation plan can be derived without re-asking.

### 7.1 Light `CLAUDE.md.tmpl`

```markdown
## First-run setup — Docker scaffold

> This block is read by Claude on first launch in this project. After scaffolding
> is complete (or the user declines), Claude must delete this entire `## First-run
> setup` section from CLAUDE.md and commit.

Before doing anything else in this project, ask the user:

1. Does this project want a Docker scaffold? (Y/n — default Y)
2. If yes:
   - What's the primary language/runtime? (python | node | go | other — free text)
   - Are there any backing services? (postgres | redis | sqlite | none | other)
   - What ports need to be exposed? (default: none)
   - Single service, or multi-service compose? (single | multi)

Then scaffold:
- `Dockerfile` (or `docker/Dockerfile.<service>` if multi-service)
- `docker-compose.yml` at the repo root
- `.dockerignore`
- Stub `.env.example` if any service needs config

Match patterns from `/opt/projects/aziz-trader/` (bind-mount `./:/app`, named
volumes for data/logs, `env_file: .env`, dedicated network) where they fit; don't
copy aziz-specific service definitions.

If the user declines (`n`), still delete this block — they don't want to be
re-prompted next session.

After scaffolding (or declining): remove this `## First-run setup` section,
including the `---` divider below, then `git add -A && git commit -m "Scaffold
Docker setup"` (or `"Decline Docker scaffold"` if declined).

---

## Memory

This LXC has a persistent memory store at `/root/.claude/projects/-opt/memory/`.
Read `MEMORY.md` there for user/project/feedback context that applies across all
projects in `/opt/projects/`. Update it when you learn something durable.

---

*Bootstrapped via `new-project` on {{DATE}}. To upgrade to the heavy
session-brief workflow, run `/promote-to-briefs` from inside a Claude session.*
```

### 7.2 `gitignore.tmpl`

```
# Python
__pycache__/
*.py[cod]
*.egg-info/
.pytest_cache/
.coverage
htmlcov/
.mypy_cache/
.ruff_cache/

# Virtual envs
.venv/
venv/

# Secrets
.env
*.env.local

# Databases
*.db
*.db-journal
*.sqlite3

# Logs
*.log
logs/

# IDE
.vscode/
.idea/
*.swp

# OS
.DS_Store
Thumbs.db

# Build
dist/
build/

# Node
node_modules/
```

### 7.3 `claude_md_heavy_preamble.md.tmpl`

```markdown
## Heavy mode — session-brief workflow

This project uses the session-brief workflow:

- **`SESSION_STATE.md`** at the repo root is the single source of truth for
  "where are we right now." Read it before any non-trivial work. Update it on
  every commit and at every state transition.
- **`docs/{{NAME}}_project_brief.md`** is the canonical project brief — what
  we're building and why. Stable; rarely edited.
- **`docs/specs/`** holds per-session build briefs (`session_N_*_brief.md`)
  and per-task specs (`*_spec.md`). New work starts as a brief or spec here
  before any code is written.
- **`/opt/{{NAME}}-build-docs/`** is an external scratch dir for drafting
  briefs/specs during long brainstorming sessions, outside the working tree.
  Finalize and copy into `docs/specs/` before implementing.

Before any non-trivial work: read `SESSION_STATE.md`, then the relevant
brief/spec under `docs/specs/`. If neither exists for the work you're about
to do, draft one first.

---

```

### 7.4 `claude_md_minimal_addendum.md.tmpl`

Used only by `promote-to-briefs` when `CLAUDE.md` is missing (rare — happens when promoting a project that pre-dates `new-project`). Concatenated after the heavy preamble to produce a complete, minimal `CLAUDE.md`.

The memory-pointer block here is intentionally a near-duplicate of the one in §7.1 — keep them in sync if either is edited.

```markdown
## Memory

This LXC has a persistent memory store at `/root/.claude/projects/-opt/memory/`.
Read `MEMORY.md` there for user/project/feedback context that applies across all
projects in `/opt/projects/`. Update it when you learn something durable.

---

*Promoted to heavy mode via `/promote-to-briefs` on {{DATE}}.*
```

### 7.5 `SESSION_STATE.md.tmpl`

```markdown
# Session State

**Single source of truth for "where are we right now."**
Future Claude reading this should be able to resume work without reading the
full conversation history. Update on every commit and at every state transition.

---

## Current state

- **Active session:** _(not started — fill in when first session opens)_
- **Latest commit on origin/main:** _(populated automatically as work happens)_
- **Working tree:** clean.
- **Branch:** main.

## What's running in production

_(none yet)_

## Next action

_(populated by current session brief)_

## Open questions

_(decisions deferred to a later session)_
```

### 7.6 `project_brief.md.tmpl`

```markdown
# `{{NAME}}` — Project Brief

**Status:** Draft — first version written via `/promote-to-briefs`.

---

## 1. What we're building

_(one paragraph: what this project is, what it does, who/what it's for)_

## 2. Core design principles

_(non-negotiables that inform every downstream choice — 3–5 bullets)_

## 3. Stack & infrastructure

_(confirmed services, deferred services, run cost)_

## 4. Build sessions

_(numbered list of build sessions, each linking to its brief in docs/specs/)_

## 5. Open questions

_(things unresolved at brief-write time)_
```

### 7.7 `_template_session_brief.md`

```markdown
# Session N — <Title>

**Goal:** _(one sentence)_
**Out of scope:** _(what we're NOT doing this session)_
**Acceptance:** _(how we know we're done)_

---

## Context

_(what state the project is in, why this session matters now — link to
SESSION_STATE.md and the project brief)_

## Plan

_(numbered steps; each step should be small enough to commit independently)_

## Risks & open questions

_(things that might force a pivot mid-session)_
```

### 7.8 `_template_spec.md`

```markdown
# <Topic> — Spec

**Status:** Draft / Approved / Implemented
**Context:** _(why this spec exists — bug, feature, refactor)_

---

## Problem

_(what's broken or missing, in concrete terms with examples)_

## Proposed change

_(the fix or feature, in enough detail that someone else could implement it)_

## Files affected

_(paths + nature of change)_

## Tests

_(how we verify the change works and didn't break adjacent things)_

## Out of scope

_(what we deliberately are NOT addressing here)_
```

## 8. Install path (`/opt/tools/Makefile`)

Two targets, both idempotent:

```make
.PHONY: install uninstall

install:
	ln -sf /opt/tools/bin/new-project       /usr/local/bin/new-project
	ln -sf /opt/tools/bin/promote-to-briefs /usr/local/bin/promote-to-briefs
	mkdir -p $${HOME}/.claude/commands
	cp -f /opt/tools/commands/promote-to-briefs.md $${HOME}/.claude/commands/promote-to-briefs.md
	@echo "✓ installed: new-project, promote-to-briefs, /promote-to-briefs slash command"

uninstall:
	rm -f /usr/local/bin/new-project
	rm -f /usr/local/bin/promote-to-briefs
	rm -f $${HOME}/.claude/commands/promote-to-briefs.md
	@echo "✓ uninstalled. /opt/tools/ itself is left in place — rm -rf manually if desired."
```

`/opt/tools/` itself is `git init`'d during implementation; that's how this design doc gets versioned.

## 9. Verification — smoke test

After `make install`, the implementation must verify all of the following. Items 1–3 are simple existence checks; item 4 is a multi-step end-to-end smoke test.

1. `which new-project` returns `/usr/local/bin/new-project`.
2. `which promote-to-briefs` returns `/usr/local/bin/promote-to-briefs`.
3. `~/.claude/commands/promote-to-briefs.md` exists and is non-empty.
4. End-to-end smoke: `new-project smoketest && promote-to-briefs smoketest`. Verify:
   - `/opt/projects/smoketest/CLAUDE.md` exists, contains `## First-run setup`, contains `## Heavy mode`, has a populated `{{DATE}}` substitution (no literal `{{DATE}}` left).
   - `/opt/projects/smoketest/.gitignore` exists and contains `__pycache__/`.
   - `/opt/projects/smoketest/SESSION_STATE.md` exists.
   - `/opt/projects/smoketest/docs/smoketest_project_brief.md` exists with `smoketest` substituted (no literal `{{NAME}}`).
   - `/opt/projects/smoketest/docs/specs/_template_session_brief.md` exists.
   - `/opt/smoketest-build-docs/` exists and is a plain dir (no `.git`).
   - `git -C /opt/projects/smoketest log --oneline` shows exactly one commit (`Initial scaffold via new-project`) — promote-to-briefs did not auto-commit.
   - Re-running `promote-to-briefs smoketest` prints `[skip]` for every file and exits 0.
   - `cleanup`: `rm -rf /opt/projects/smoketest /opt/smoketest-build-docs`.

The slash-command interactive flow is the only thing this can't smoke-test mechanically — the user verifies it once by running `/promote-to-briefs` in a real Claude session against a real project.

## 10. Out of scope

Explicitly *not* covered by this design (call them out so they don't sneak into the implementation plan):

- **Language-aware `.gitignore`** (Q4b — YAGNI for now).
- **`--force` flag for either command** (Q5a — footgun).
- **Auto-clone the slash command from another machine** — single-machine LXC tooling.
- **Project lifecycle commands** (archive, delete, rename) — not needed yet.
- **Templated CI workflows** (`.github/workflows/`) — projects on this LXC don't currently use CI; revisit if/when the first one does.
- **Customizable templates per language/framework** — flat templates for now.
- **Drafting the first session brief during promotion** — explicitly deferred per Section 6 Step 4.

## 11. Future work

If patterns emerge that justify revisiting:

- A `/new-session-brief <N> <title>` slash command that copies `_template_session_brief.md` to `docs/specs/session_<N>_<slug>_brief.md` and walks the user through filling it in. Symmetric with `/promote-to-briefs`.
- `--lang python|node|go` flag on `new-project` once 3+ projects have demonstrated `.gitignore` noise actually hurts.
- Promote-from-light *upgrade* of a project's existing `.gitignore` (currently we leave it alone — the catchall is already a superset).
